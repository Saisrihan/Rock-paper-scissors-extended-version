import pygame
from multi_agent_rps_env import MultiAgentRockPaperScissorsEnv
import numpy as np

if __name__ == "__main__":
    pygame.init()
    env = MultiAgentRockPaperScissorsEnv(num_actions=5)
    num_episodes = 8
    q_values = [[np.zeros(env.num_actions) for _ in range(env.num_actions)] for _ in range(env.players)]
    epsilon = 0.05
    learning_rate = 0.05
    discount_factor = 0.6

    for episode in range(num_episodes):
        state = env.reset()
        done = False

        while not done:
            actions = []
            for i in range(env.players):
                # Implement epsilon-greedy policy for action selection
                if np.random.uniform(0, 1) < epsilon:
                    action = np.random.choice(env.num_actions)
                else:
                    action = np.argmax(q_values[i][state])
                actions.append(action)

            next_state, rewards, done, _ = env.step(actions)

            # Update Q-values using Q-learning update rule
            for i in range(env.players):
                q_values[i][state][actions[i]] += learning_rate * (
                        rewards[i] + discount_factor * np.max(q_values[i][next_state]) - q_values[i][state][actions[i]])

            state = next_state

        # Declare the winner after completing the cycles
        winner = np.argmax(env.agent_scores)
        print(f"Episode {episode + 1}: {env.agent_names[winner]} wins with a score of {env.agent_scores[winner]}")

    env.close()
